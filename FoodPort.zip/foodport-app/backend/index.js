const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(bodyParser.json());

/*
  Backend stub for FoodPort.
  - /api/pricing : calculate store prices for a list (STUB: returns fake data).
  - /api/route   : calculate transit route to given lat/lng (STUB: returns fake route).
  - /api/share   : post/get shared lists in-memory (DEMO only).
  Replace stubs with real API integrations:
    - Grocery/pricing: use partner APIs or web-scrape store pages (e.g., Walmart, Kroger)
    - Transit routing: use Google Maps Directions API, Mapbox Directions, or a GTFS-based planner.
    - Payments: integrate Stripe/PayPal for accepting fees.
*/

let shared = []; // in-memory store for demo

app.post("/api/pricing", (req, res) => {
  const {location, items} = req.body;
  // STUB: produce two fake stores with random prices
  const stores = [{
    storeId: "s1",
    name: "Budget Grocer",
    address: "123 Main St",
    lat: 42.33,
    lng: -83.04,
    priceTotal: 0,
    items: []
  },{
    storeId: "s2",
    name: "Premium Market",
    address: "456 Center Ave",
    lat: 42.34,
    lng: -83.02,
    priceTotal: 0,
    items: []
  }];
  // assign fake prices
  for(const s of stores){
    let total = 0;
    for(const it of items){
      const price = Math.max(0.5, Math.round((Math.random()*5 + 1)*100)/100);
      s.items.push({item: it, price});
      total += price;
    }
    s.priceTotal = Math.round(total*100)/100;
  }
  res.json(stores);
});

app.post("/api/route", (req, res) => {
  const {from, to} = req.body;
  // STUB: return fake route info
  res.json({
    durationMinutes: Math.floor(Math.random()*30)+5,
    transitMode: "bus + walk",
    steps: [
      "Walk to bus stop",
      "Take bus 12 for 10 stops",
      "Walk to store"
    ]
  });
});

app.post("/api/share", (req, res) => {
  const {listName, items, pickupLocation, fee} = req.body;
  const id = Date.now().toString();
  shared.push({id, listName, items, pickupLocation, fee: Number(fee)});
  res.json({ok:true, id});
});

app.get("/api/share", (req, res) => {
  res.json(shared);
});

app.listen(4000, ()=>console.log("FoodPort backend running on :4000"));
