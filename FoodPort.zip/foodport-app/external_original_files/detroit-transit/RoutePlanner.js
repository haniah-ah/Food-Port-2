import React, { useState } from 'react';

// Import service function to calculate routes
import { calculateRoutes } from '../../services/transitService';

// Component for entering start and destination points
const RoutePlanner = ({ onRoutesCalculated, setLoading }) => {
  // State for the starting location
  const [startPoint, setStartPoint] = useState('');
  
  // State for the destination location
  const [endPoint, setEndPoint] = useState('');

  // Handle form submission
  const handleSubmit = async (e) => {
    // Prevent default form submission behavior
    e.preventDefault();
    
    // Don't proceed if either field is empty
    if (!startPoint || !endPoint) return;
    
    // Set loading state to true while calculating
    setLoading(true);
    
    try {
      // Call the service to calculate routes
      const routes = await calculateRoutes(startPoint, endPoint);
      
      // Pass the calculated routes back to parent component
      onRoutesCalculated(routes);
    } catch (error) {
      console.error('Error calculating routes:', error);
    }
    
    // Reset loading state when done
    setLoading(false);
  };

  return (
    <div className="route-planner">
      <form onSubmit={handleSubmit}>
        {/* Input for starting location */}
        <div className="input-group">
          <label htmlFor="start">From:</label>
          <input
            type="text"
            id="start"
            value={startPoint}
            onChange={(e) => setStartPoint(e.target.value)}
            placeholder="Enter starting location"
          />
        </div>
        
        {/* Input for destination location */}
        <div className="input-group">
          <label htmlFor="end">To:</label>
          <input
            type="text"
            id="end"
            value={endPoint}
            onChange={(e) => setEndPoint(e.target.value)}
            placeholder="Enter destination"
          />
        </div>
        
        {/* Submit button to calculate routes */}
        <button type="submit">Find Routes</button>
      </form>
    </div>
  );
};

export default RoutePlanner;