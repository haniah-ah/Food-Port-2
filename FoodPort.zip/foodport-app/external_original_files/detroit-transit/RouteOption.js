import React, { useState } from 'react';

// Import component for rating a route
import RouteRating from './RouteRating';

// Component to display a single transportation option
const RouteOption = ({ route }) => {
  // State to control whether to show the rating dialog
  const [showRating, setShowRating] = useState(false);

  // Function to handle when user wants to rate this route
  const handleRateRoute = () => {
    setShowRating(true);
  };

  return (
    <div className="route-option">
      {/* Header with transportation method and time */}
      <div className="route-header">
        <h3>{route.method}</h3>
        <span className="time">{route.time}</span>
      </div>
      
      {/* Details about cost, emissions, and safety */}
      <div className="route-details">
        <div className="detail">
          <span className="label">Cost:</span>
          <span className="value">${route.cost}</span>
        </div>
        <div className="detail">
          <span className="label">CO2 Emissions:</span>
          <span className="value">{route.emissions} kg</span>
        </div>
        <div className="detail">
          <span className="label">Safety:</span>
          <span className="value">{route.safety}/5</span>
        </div>
      </div>
      
      {/* Button to rate this route */}
      <button className="rate-btn" onClick={handleRateRoute}>
        Rate This Route
      </button>
      
      {/* Show rating dialog if user clicked the rate button */}
      {showRating && (
        <RouteRating 
          routeId={route.id} 
          onClose={() => setShowRating(false)} 
        />
      )}
    </div>
  );
};

export default RouteOption;