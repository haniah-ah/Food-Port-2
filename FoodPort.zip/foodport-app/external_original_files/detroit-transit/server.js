// Import required modules
const express = require('express');
const cors = require('cors');
const path = require('path');

// Load environment variables from .env file
require('dotenv').config();

// Import route handlers
const transitRoutes = require('./routes/transit');
const groceryRoutes = require('./routes/groceries');
const commuterRoutes = require('./routes/commuter');
const ratingRoutes = require('./routes/ratings');

// Create Express application
const app = express();

// Set port from environment variable or default to 5000
const PORT = process.env.PORT || 5000;

// Middleware to enable Cross-Origin Resource Sharing
app.use(cors());

// Middleware to parse JSON request bodies
app.use(express.json());

// API Routes - mount different route handlers
app.use('/api/transit', transitRoutes);
app.use('/api/groceries', groceryRoutes);
app.use('/api/commuter', commuterRoutes);
app.use('/api/ratings', ratingRoutes);

// Serve static files in production environment
if (process.env.NODE_ENV === 'production') {
  // Serve static files from the React build directory
  app.use(express.static(path.join(__dirname, '../client/build')));
  
  // Handle React routing, return all requests to React app
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}

// Start the server and listen on the specified port
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});