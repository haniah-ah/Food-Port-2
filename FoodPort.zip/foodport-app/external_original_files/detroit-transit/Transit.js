import React, { useState } from 'react';
import RoutePlanner from '../components/transit/RoutePlanner';
import RouteResults from '../components/transit/RouteResults';
import '../styles/Transit.css';

const Transit = () => {
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleRoutesCalculated = (calculatedRoutes) => {
    setRoutes(calculatedRoutes);
  };

  return (
    <div className="transit-page">
      <h1>Plan Your Trip</h1>
      <RoutePlanner 
        onRoutesCalculated={handleRoutesCalculated}
        setLoading={setLoading}
      />
      {loading ? (
        <div className="loading">Calculating best routes...</div>
      ) : (
        <RouteResults routes={routes} />
      )}
    </div>
  );
};

export default Transit;