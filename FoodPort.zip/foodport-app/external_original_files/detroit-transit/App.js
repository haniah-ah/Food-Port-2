// Import necessary React and React Router components
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

// Import custom components
import Header from './components/common/Header';
import Navigation from './components/common/Navigation';
import Home from './pages/Home';
import Transit from './pages/Transit';
import Food from './pages/Food';
import Commuter from './pages/Commuter';

// Import CSS styles
import './styles/App.css';

// Main App component that serves as the root of our application
function App() {
  // State to track the current page for navigation highlighting
  const [currentPage, setCurrentPage] = useState('home');

  return (
    // Router component enables client-side routing
    <Router>
      <div className="App">
        {/* Header component with app title and logo */}
        <Header />
        
        {/* Main content area that changes based on current route */}
        <main className="main-content">
          <Switch>
            {/* Define routes for different pages */}
            <Route exact path="/" component={Home} />
            <Route path="/transit" component={Transit} />
            <Route path="/food" component={Food} />
            <Route path="/commuter" component={Commuter} />
          </Switch>
        </main>
        
        {/* Bottom navigation component */}
        <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      </div>
    </Router>
  );
}

export default App;

//still needs to be connected with a front end mockup - an interactive ui/ux design