import React from 'react';

// Import component to display individual route options
import RouteOption from './RouteOption';

// Component to display all calculated route options
const RouteResults = ({ routes }) => {
  // Show prompt if no routes have been calculated yet
  if (routes.length === 0) {
    return (
      <div className="route-results">
        <p>Enter your start and destination to see transportation options.</p>
      </div>
    );
  }

  // Display all available route options
  return (
    <div className="route-results">
      <h2>Available Routes</h2>
      <div className="routes-list">
        {/* Map through each route and create a RouteOption component */}
        {routes.map((route, index) => (
          <RouteOption key={index} route={route} />
        ))}
      </div>
    </div>
  );
};

export default RouteResults;