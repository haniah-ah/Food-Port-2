// Mock data for different transportation methods
// In a real application, this would be replaced with actual API calls
const TRANSIT_DATA = {
  bus: {
    speed: 20, // Average speed in mph
    costPerMile: 0.15, // Cost per mile in dollars
    emissions: 0.12, // CO2 emissions in kg per mile
    safety: 4, // Safety rating on a scale of 1-5
    waitTime: 10 // Average wait time in minutes
  },
  bike: {
    speed: 10,
    costPerMile: 0.05,
    emissions: 0,
    safety: 3,
    waitTime: 2
  },
  walk: {
    speed: 3,
    costPerMile: 0,
    emissions: 0,
    safety: 4,
    waitTime: 0
  },
  qline: {
    speed: 25,
    costPerMile: 0.20,
    emissions: 0.08,
    safety: 5,
    waitTime: 5
  },
  car: {
    speed: 30,
    costPerMile: 0.60,
    emissions: 0.41,
    safety: 4,
    waitTime: 3
  }
};

// Mock function to calculate distance between two points
// In a real app, this would use a geocoding service and calculate actual distance
const calculateDistance = (start, end) => {
  // For demonstration purposes, return a fixed distance of 5 miles
  // In production, you would use the Google Maps API or similar
  return 5; // miles
};

// Main function to calculate routes between two points
const calculateRoute = async (start, end) => {
  // Calculate distance between start and end points
  const distance = calculateDistance(start, end);
  const routes = [];
  
  // Calculate details for each transportation method
  for (const [method, data] of Object.entries(TRANSIT_DATA)) {
    // Calculate travel time (distance divided by speed, converted to minutes)
    const travelTime = (distance / data.speed) * 60;
    
    // Total time includes travel time plus wait time
    const totalTime = travelTime + data.waitTime;
    
    // Calculate cost based on distance and cost per mile
    const cost = (distance * data.costPerMile).toFixed(2);
    
    // Calculate emissions based on distance and emissions per mile
    const emissions = (distance * data.emissions).toFixed(2);
    
    // Add this transportation option to the routes array
    routes.push({
      id: Math.random().toString(36).substr(2, 9), // Generate unique ID
      method: method.charAt(0).toUpperCase() + method.slice(1), // Capitalize method name
      time: `${Math.round(totalTime)} min`, // Format time as string
      cost,
      emissions,
      safety: data.safety,
      distance: `${distance.toFixed(1)} miles` // Format distance as string
    });
  }
  
  // Sort routes by time (fastest first)
  return routes.sort((a, b) => {
    const aTime = parseInt(a.time);
    const bTime = parseInt(b.time);
    return aTime - bTime;
  });
};

// Export the calculateRoute function for use in other modules
module.exports = { calculateRoute };