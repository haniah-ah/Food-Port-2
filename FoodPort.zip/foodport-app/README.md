# FoodPort (Demo scaffold)
This scaffold includes a React frontend and a simple Node/Express backend with stubbed endpoints.
It demonstrates where to integrate:
- Store pricing APIs (grocery data)
- Transit routing APIs (Google Maps / Mapbox / local transit GTFS)
- Authentication and payments (Stripe)
